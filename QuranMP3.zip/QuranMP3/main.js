var recitersList = [
        { 
        name: "إختر المقرء", 
        image: "https://telegra.ph/file/ca7396666044b3ecd0943.jpg" },
        
        { 
        
        name: "أحمد علي العجمي", 
        image: "https://telegra.ph/file/7769a90ea6ebf05077349.jpg" ,
        
        audioFiles: [
           "music.mp3",
            "https://server10.mp3quran.net/download/ajm/001.mp3",
            "https://server10.mp3quran.net/download/ajm/002.mp3",
    "https://server10.mp3quran.net/download/ajm/003.mp3",
            "https://server10.mp3quran.net/download/ajm/004.mp3",
     "https://server10.mp3quran.net/download/ajm/005.mp3",
            "https://server10.mp3quran.net/download/ajm/006.mp3",
      "https://server10.mp3quran.net/download/ajm/007.mp3",
            "https://server10.mp3quran.net/download/ajm/008.mp3",
     "https://server10.mp3quran.net/download/ajm/009.mp3",
            "https://server10.mp3quran.net/download/ajm/010.mp3",
   "https://server10.mp3quran.net/download/ajm/011.mp3",
            "https://server10.mp3quran.net/download/ajm/012.mp3",
    "https://server10.mp3quran.net/download/ajm/013.mp3",
            "https://server10.mp3quran.net/download/ajm/014.mp3",
     "https://server10.mp3quran.net/download/ajm/015.mp3",
            "https://server10.mp3quran.net/download/ajm/016.mp3",
      "https://server10.mp3quran.net/download/ajm/017.mp3",
            "https://server10.mp3quran.net/download/ajm/018.mp3",
     "https://server10.mp3quran.net/download/ajm/019.mp3",
            "https://server10.mp3quran.net/download/ajm/020.mp3",
             "https://server10.mp3quran.net/download/ajm/021.mp3",
            "https://server10.mp3quran.net/download/ajm/022.mp3",
    "https://server10.mp3quran.net/download/ajm/023.mp3",
            "https://server10.mp3quran.net/download/ajm/024.mp3",
     "https://server10.mp3quran.net/download/ajm/025.mp3",
            "https://server10.mp3quran.net/download/ajm/026.mp3",
      "https://server10.mp3quran.net/download/ajm/027.mp3",
            "https://server10.mp3quran.net/download/ajm/028.mp3",
     "https://server10.mp3quran.net/download/ajm/029.mp3",
            "https://server10.mp3quran.net/download/ajm/030.mp3",
             "https://server10.mp3quran.net/download/ajm/031.mp3",
            "https://server10.mp3quran.net/download/ajm/032.mp3",
    "https://server10.mp3quran.net/download/ajm/033.mp3",
            "https://server10.mp3quran.net/download/ajm/034.mp3",
     "https://server10.mp3quran.net/download/ajm/035.mp3",
            "https://server10.mp3quran.net/download/ajm/036.mp3",
      "https://server10.mp3quran.net/download/ajm/037.mp3",
            "https://server10.mp3quran.net/download/ajm/038.mp3",
     "https://server10.mp3quran.net/download/ajm/039.mp3",
            "https://server10.mp3quran.net/download/ajm/040.mp3",     
             "https://server10.mp3quran.net/download/ajm/041.mp3",
            "https://server10.mp3quran.net/download/ajm/042.mp3",
            
"https://server10.mp3quran.net/download/ajm/043.mp3",
            "https://server10.mp3quran.net/download/ajm/044.mp3",
     "https://server10.mp3quran.net/download/ajm/045.mp3",
            "https://server10.mp3quran.net/download/ajm/046.mp3",
      "https://server10.mp3quran.net/download/ajm/047.mp3",
            "https://server10.mp3quran.net/download/ajm/048.mp3",
     "https://server10.mp3quran.net/download/ajm/049.mp3",
            "https://server10.mp3quran.net/download/ajm/050.mp3",
    "https://server10.mp3quran.net/download/ajm/051.mp3",
            "https://server10.mp3quran.net/download/ajm/052.mp3",
    "https://server10.mp3quran.net/download/ajm/053.mp3",
            "https://server10.mp3quran.net/download/ajm/054.mp3",
     "https://server10.mp3quran.net/download/ajm/055.mp3",
            "https://server10.mp3quran.net/download/ajm/056.mp3",
      "https://server10.mp3quran.net/download/ajm/057.mp3",
            "https://server10.mp3quran.net/download/ajm/058.mp3",
     "https://server10.mp3quran.net/download/ajm/059.mp3",
            "https://server10.mp3quran.net/download/ajm/060.mp3", 
             "https://server10.mp3quran.net/download/ajm/061.mp3",
            "https://server10.mp3quran.net/download/ajm/062.mp3",
    "https://server10.mp3quran.net/download/ajm/063.mp3",
            "https://server10.mp3quran.net/download/ajm/064.mp3",
     "https://server10.mp3quran.net/download/ajm/065.mp3",
            "https://server10.mp3quran.net/download/ajm/066.mp3",
      "https://server10.mp3quran.net/download/ajm/067.mp3",
            "https://server10.mp3quran.net/download/ajm/068.mp3",
     "https://server10.mp3quran.net/download/ajm/069.mp3",
            "https://server10.mp3quran.net/download/ajm/070.mp3",      
             "https://server10.mp3quran.net/download/ajm/071.mp3",
            "https://server10.mp3quran.net/download/ajm/072.mp3",
    "https://server10.mp3quran.net/download/ajm/073.mp3",
            "https://server10.mp3quran.net/download/ajm/074.mp3",
     "https://server10.mp3quran.net/download/ajm/075.mp3",
            "https://server10.mp3quran.net/download/ajm/076.mp3",
      "https://server10.mp3quran.net/download/ajm/077.mp3",
            "https://server10.mp3quran.net/download/ajm/078.mp3",
     "https://server10.mp3quran.net/download/ajm/079.mp3",
            "https://server10.mp3quran.net/download/ajm/080.mp3",
             "https://server10.mp3quran.net/download/ajm/081.mp3",
            "https://server10.mp3quran.net/download/ajm/082.mp3",
    "https://server10.mp3quran.net/download/ajm/083.mp3",
            "https://server10.mp3quran.net/download/ajm/084.mp3",
     "https://server10.mp3quran.net/download/ajm/085.mp3",
            "https://server10.mp3quran.net/download/ajm/086.mp3",
      "https://server10.mp3quran.net/download/ajm/087.mp3",
            "https://server10.mp3quran.net/download/ajm/088.mp3",
     "https://server10.mp3quran.net/download/ajm/089.mp3",
            "https://server10.mp3quran.net/download/ajm/090.mp3",     
             "https://server10.mp3quran.net/download/ajm/091.mp3",
            "https://server10.mp3quran.net/download/ajm/092.mp3",
    "https://server10.mp3quran.net/download/ajm/093.mp3",
            "https://server10.mp3quran.net/download/ajm/094.mp3",
     "https://server10.mp3quran.net/download/ajm/095.mp3",
            "https://server10.mp3quran.net/download/ajm/096.mp3",
      "https://server10.mp3quran.net/download/ajm/097.mp3",
            "https://server10.mp3quran.net/download/ajm/098.mp3",
     "https://server10.mp3quran.net/download/ajm/099.mp3",
            "https://server10.mp3quran.net/download/ajm/100.mp3",
             "https://server10.mp3quran.net/download/ajm/101.mp3",
            "https://server10.mp3quran.net/download/ajm/102.mp3",
    "https://server10.mp3quran.net/download/ajm/103.mp3",
            "https://server10.mp3quran.net/download/ajm/104.mp3",
     "https://server10.mp3quran.net/download/ajm/105.mp3",
            "https://server10.mp3quran.net/download/ajm/106.mp3",
      "https://server10.mp3quran.net/download/ajm/107.mp3",
            "https://server10.mp3quran.net/download/ajm/108.mp3",
     "https://server10.mp3quran.net/download/ajm/109.mp3",
            "https://server10.mp3quran.net/download/ajm/110.mp3",   
             "https://server10.mp3quran.net/download/ajm/111.mp3",
            "https://server10.mp3quran.net/download/ajm/112.mp3",
"https://server10.mp3quran.net/download/ajm/113.mp3",
            "https://server10.mp3quran.net/download/ajm/114.mp3",            
                   ]
        
        },
        { name: "سعود الشريم", image: "https://i.pinimg.com/564x/ad/79/67/ad79679d76062df7166c6e2f52d397d6.jpg" },
        { name: "أبو بكر الشاطر", image: "https://i.pinimg.com/564x/d6/c6/33/d6c633aadb82ce2d974d1147ed071090.jpg" },
        { name: "سعد الغامدي", image: "https://i.pinimg.com/564x/85/27/cf/8527cf694f379425e43b9a4fe54b6cfb.jpg" },      
        { name: "ماهر المعيقلي", image: "https://s-media-cache-ak0.pinimg.com/564x/ab/cc/99/abcc9949d0419ef1f0963a54aef06397.jpg" },
        { name: "عبد الباسط عبد الصمد", image: "https://i.pinimg.com/564x/52/95/ae/5295ae7c08e4ebdc7eda3ddb5c6c0a19.jpg" },
     { name: "ياسر الدوسري", image: "https://s-media-cache-ak0.pinimg.com/564x/32/3e/17/323e173f4833680898f51240bedd4973.jpg" },
        { name: "إبراهيم الأخضر", image: "https://i.pinimg.com/564x/95/e4/90/95e490b6c075566f62197da844dae903.jpg" },
     { name: "خليفة الطنيجي", image: "https://i.pinimg.com/564x/56/1b/17/561b17211f66cfb725f12b5fca5312d3.jpg" },
        { name: "حسن صالح", image: "https://i.pinimg.com/564x/de/01/63/de016366fb22e40d2db58a122305c05e.jpg" },
     { name: "عبد الرحمن العوسي", image: "https://i.pinimg.com/564x/8f/95/8e/8f958ed8cbafc0c0dcf5c58e3c001221.jpg" },
        { name: "العيون الكوشي", image: "https://i.pinimg.com/564x/ef/cf/7f/efcf7f30467f6962fd15fa34f2a417cc.jpg" },
     { name: "عمر القزابري", image: "https://i.pinimg.com/564x/0b/62/75/0b6275b2341fcb087fb9a3de47463c1a.jpg" },
        { name: "فارس عباد", image: "https://s-media-cache-ak0.pinimg.com/564x/2b/28/ae/2b28aef3f9678b7cd89315d5ffceba2f.jpg" },
     { name: "محمد جبريل", image: "https://i.pinimg.com/564x/fe/69/9e/fe699e3970550240fb078ee720773db4.jpg" },
        { name: "مشاري العفاسي", image: "https://i.pinimg.com/564x/0a/40/9e/0a409ef09a55700877c20d7195fe9126.jpg" },
     { name: "المنشاوي", image: "https://i.pinimg.com/564x/21/76/8d/21768d297bd3460f7339b7b755f53d03.jpg" },
        { name: "ياسين الجزائري", image: "https://i.pinimg.com/564x/47/26/1a/47261a9e304a8aa18e94d7bb67baa6db.jpg" },
     { name: "وديع اليمني", image: "https://i.pinimg.com/564x/e9/9e/90/e99e9020d1d7cd27beaaed7010086d4a.jpg" },
        { name: "صلاح بوخاطر", image: "https://s-media-cache-ak0.pinimg.com/564x/24/60/63/246063b8cd37a179fd261f0c40c57ef0.jpg" },
    
     
        // ... إضافة باقي المقرئين
    ];

    function changeReciter() {
    var reciterSelect = document.getElementById("reciters");
    var reciterImage = document.getElementById("reciterImage");
    var reciterName = document.getElementById("reciterName");
    var audioElement = document.querySelector("audio");

    var selectedReciterIndex = reciterSelect.selectedIndex;
    var selectedReciter = recitersList[selectedReciterIndex];

    if (selectedReciter) {
        reciterImage.src = selectedReciter.image;
        reciterName.textContent = selectedReciter.name;

        // تحديد ملف الصوت بناءً على السورة المحددة
        var selectedSurahIndex = document.getElementById("surahs").selectedIndex;
        var selectedAudioFile = selectedReciter.audioFiles[selectedSurahIndex];

        audioElement.src = selectedAudioFile;
    }
}
    // ... (الجزء السابق من الكود)

    function changeSurah() {
        var reciterSelect = document.getElementById("reciters");
        var selectedReciterIndex = reciterSelect.selectedIndex;
        var selectedReciter = recitersList[selectedReciterIndex];

        var surahSelect = document.getElementById("surahs");
        var selectedSurahIndex = surahSelect.selectedIndex;

        var audioElement = document.querySelector("audio");
        var selectedAudioFile = selectedReciter.audioFiles[selectedSurahIndex];

        audioElement.src = selectedAudioFile;
    }
